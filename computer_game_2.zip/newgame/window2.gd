extends Window

@onready var label_node: Label = $Label2

func _ready():
	self.visible = false
	get_window().size_changed.connect(update_label_size)
	update_label_size()
	get_window().close_requested.connect(func():
		self.visible = false
)

func _process(delta):
	var screen_size = DisplayServer.screen_get_size()
	var new_pos = position

	# Clamp horizontally
	if new_pos.x < 0:
		new_pos.x = 0
	elif new_pos.x + size.x > screen_size.x:
		new_pos.x = screen_size.x - size.x

	# Clamp vertically
	if new_pos.y < 0:
		new_pos.y = 0
	elif new_pos.y + size.y > screen_size.y:
		new_pos.y = screen_size.y - size.y

	position = new_pos


func on_2_pressed() -> void:
	self.visible = true

func update_label_size():
	label_node.size = Vector2(size.x - 20, label_node.size.y)
